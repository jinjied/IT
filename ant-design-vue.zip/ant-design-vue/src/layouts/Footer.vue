<template>
    <div>Personal CRM ©2021 Created by Team 066</div> 
</template>
<script>
export default {
    
}
</script>
<style>

</style>